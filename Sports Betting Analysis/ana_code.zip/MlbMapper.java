import java.io.IOException;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;
public class MlbMapper
extends Mapper<LongWritable, Text, Text, Text> {
@Override
public void map(LongWritable key, Text value, Context context)
throws IOException, InterruptedException {
String line = value.toString();
String [] split = line.split(",");
if (split.length == 23) {
context.write(new Text(split[2] + ", " + split[3] + ", " + split[4] + ", " + split[14] + ", " + split[15] + "," + split[16] + "," + split[19] + ","), new Text(split[21]));
}
}
}